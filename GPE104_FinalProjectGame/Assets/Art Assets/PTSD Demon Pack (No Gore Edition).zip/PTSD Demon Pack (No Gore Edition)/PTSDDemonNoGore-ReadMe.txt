Credit: Molly "Cougarmint" Willits
Created by hand using MS Paint and Photoshop Educational Edition 6.0.

Licences CC-BY 3.0.

Free Commercial Use: Yes
Free Personal Use: Yes

Included in this Pack:
ptsddemon_noblood.png
ptsddemon_noblood_lrg.png
PTSDDemonSymbolism.txt

Alt Demons Folder:
ptsddemon_nogore.png
ptsddemon_nogore_lrg.png
ptsddemon_notail_noblood.png

Gibs Folder:
demonwing.png
frozenheart.png
scorpiontail.png
tentacle1.png
tentacle2.png
tentacle3.png
tentacle4.png
thornbranch1.png
thornbranch3.png
thornscraps.png

Incomplete Demon Folder:
ptsddemon_incomplete1a.png
ptsddemon_incomplete2a.png
ptsddemon_incomplete4.png
ptsddemon_incomplete5.png

Donations: Not needed, but appreciated. Contact me if you'd like to make a donation.